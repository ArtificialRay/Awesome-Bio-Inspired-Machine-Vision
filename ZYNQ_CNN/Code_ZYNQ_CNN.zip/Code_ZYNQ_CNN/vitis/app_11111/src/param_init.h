#include <stdio.h>

void conv_param_init();
void affine1_param_init();
void affine2_param_init();
